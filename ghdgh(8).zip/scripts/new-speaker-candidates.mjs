import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const speakersPath = path.join(root, "src/data/speakers.json");
const speakers = JSON.parse(fs.readFileSync(speakersPath, "utf8"));
const existingIds = new Set(speakers.map(s => s.id));
const existingPairs = new Set(speakers.map(s => `${s.brand.toLowerCase()}|${s.model.toLowerCase()}`));

export const CANDIDATES = [
  {
    id: "atc-scm25a-pro",
    brand: "ATC",
    model: "SCM25A Pro",
    category: "studio-monitor",
    year: 2010,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 3,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 47,
      high_hz: 22000,
      status: "MANUFACTURER_VERIFIED",
      source: "ATC Loudspeaker Technology Ltd Manufacturer Specs (-6dB 47Hz - 22kHz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 235,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "ATC Tri-amp Pack: Bass 150W, Mid 60W, HF 25W continuous",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 7,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "ATC 7 inch / 175mm carbon-paper bass driver",
      sourceType: "MANUFACTURER"
    },
    notes: "Active 3-way compact nearfield/midfield studio monitor with SM75-150 soft dome midrange"
  },
  {
    id: "atc-scm45a-pro",
    brand: "ATC",
    model: "SCM45A Pro",
    category: "studio-monitor",
    year: 2015,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 4,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 42,
      high_hz: 25000,
      status: "MANUFACTURER_VERIFIED",
      source: "ATC Manufacturer Specifications (-6dB 42Hz - 25kHz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 235,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "ATC Tri-amp Pack: Bass 150W, Mid 60W, HF 25W",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 6.5,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Twin 6.5 inch / 164mm short-coil carbon-paper bass drivers",
      sourceType: "MANUFACTURER"
    },
    notes: "High output active 3-way midfield studio monitor with dual bass drivers and SM75-150S midrange"
  },
  {
    id: "atc-scm50asl-pro",
    brand: "ATC",
    model: "SCM50ASL Pro",
    category: "studio-monitor",
    year: 1995,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 3,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 38,
      high_hz: 25000,
      status: "MANUFACTURER_VERIFIED",
      source: "ATC Manufacturer Specifications (-6dB 38Hz - 25kHz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 350,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "ATC Tri-amp: Bass 200W, Mid 100W, HF 50W",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 9.2,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "ATC 234mm Super Linear bass driver",
      sourceType: "MANUFACTURER"
    },
    notes: "Active 3-way reference midfield/main studio monitor with Super Linear bass driver"
  },
  {
    id: "atc-scm100asl-pro",
    brand: "ATC",
    model: "SCM100ASL Pro",
    category: "studio-monitor",
    year: 1995,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 3,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 32,
      high_hz: 25000,
      status: "MANUFACTURER_VERIFIED",
      source: "ATC Manufacturer Specifications (-6dB 32Hz - 25kHz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 350,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "ATC Tri-amp: Bass 200W, Mid 100W, HF 50W",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 12.4,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "ATC 314mm Super Linear bass driver",
      sourceType: "MANUFACTURER"
    },
    notes: "Large 3-way active reference studio monitor with 100-litre enclosure"
  },
  {
    id: "dynaudio-lyd-48",
    brand: "Dynaudio",
    model: "LYD 48",
    category: "studio-monitor",
    year: 2017,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 3,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 32,
      high_hz: 21000,
      status: "MANUFACTURER_VERIFIED",
      source: "Dynaudio Professional Specs (-6dB 32Hz - 21kHz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 180,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "Class-D Tri-amp: 80W LF, 50W MF, 50W HF",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 8,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Dynaudio 8 inch MSP woofer + 4 inch MSP midrange",
      sourceType: "MANUFACTURER"
    },
    notes: "3-way near-to-midfield active studio monitor with hand-crafted MSP drivers"
  },
  {
    id: "adam-audio-a77x",
    brand: "Adam Audio",
    model: "A77X",
    category: "studio-monitor",
    year: 2011,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 3,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 38,
      high_hz: 50000,
      status: "MANUFACTURER_VERIFIED",
      source: "ADAM Audio AX-Series Tech Specs (38Hz - 50kHz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 250,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "ADAM Audio: 2 x 100W PWM LF + 50W A/B HF",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: 1.5,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "ADAM Audio 1.5 inch voice coils on 7 inch drivers",
      sourceType: "MANUFACTURER"
    },
    woofer: {
      value: 7,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Dual 7 inch Carbon/Rohacell/Glass fibre drivers + X-ART tweeter",
      sourceType: "MANUFACTURER"
    },
    notes: "Horizontally designed 2.5-way active nearfield/midfield monitor with X-ART ribbon tweeter"
  },
  {
    id: "pmc-tb2",
    brand: "PMC",
    model: "TB2",
    category: "studio-monitor",
    year: 1999,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 2,
    active: false,
    panel: false,
    sensitivity: {
      value: 90,
      unit: "dB",
      status: "MANUFACTURER_VERIFIED",
      source: "PMC User Manual (90dB 1W/1m)",
      sourceType: "MANUFACTURER"
    },
    frequencyResponse: {
      low_hz: 40,
      high_hz: 25000,
      status: "MANUFACTURER_VERIFIED",
      source: "PMC User Manual (40Hz - 25kHz ATL transmission line)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 150,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "PMC Recommended amp power up to 150W",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: 8,
      unit: "ohm",
      status: "MANUFACTURER_VERIFIED",
      source: "PMC User Manual (8 ohms nominal)",
      sourceType: "MANUFACTURER"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 6.7,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "PMC 170mm cast alloy chassis doped cone woofer",
      sourceType: "MANUFACTURER"
    },
    notes: "Classic Advanced Transmission Line (ATL) nearfield studio monitor"
  },
  {
    id: "pmc-bb5-xbd-a",
    brand: "PMC",
    model: "BB5",
    category: "studio-monitor",
    year: 1993,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 3,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 17,
      high_hz: 25000,
      status: "MANUFACTURER_VERIFIED",
      source: "PMC Technical Specifications (17Hz - 25kHz ATL)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 2400,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "PMC / Bryston custom active amplification (HF 300W, MF 550W, LF 1500W)",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 15,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "PMC 15 inch / 380mm Radial bass driver with 4m ATL",
      sourceType: "MANUFACTURER"
    },
    notes: "Flagship reference main studio monitor with 15-inch Radial driver and 4-metre transmission line"
  },
  {
    id: "jbl-708p",
    brand: "JBL",
    model: "708P",
    category: "studio-monitor",
    year: 2017,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 2,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 35,
      high_hz: 36000,
      status: "MANUFACTURER_VERIFIED",
      source: "JBL Professional 708P Spec Sheet (-1.5dB 45Hz - 23kHz, -10dB 35Hz - 36kHz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 500,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "JBL 2-channel Class-D: 250W LF + 250W HF",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 8,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "JBL 728G 8 inch Differential Drive woofer + 2409H HF compression driver",
      sourceType: "MANUFACTURER"
    },
    notes: "High-output self-powered master reference monitor with Image Control Waveguide"
  },
  {
    id: "barefoot-footprint03",
    brand: "Barefoot Sound",
    model: "Footprint03",
    category: "studio-monitor",
    year: 2024,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 3,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 45,
      high_hz: 40000,
      status: "MANUFACTURER_VERIFIED",
      source: "Barefoot Sound Specifications (+/-1dB 45Hz - 40kHz, -3dB at 42Hz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 260,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "Barefoot 3-way Class-D: 100W LF, 100W MF, 60W HF",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 6.5,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Barefoot 6.5 inch aluminium cone woofer + 3.5 inch midrange + 1 inch ring radiator",
      sourceType: "MANUFACTURER"
    },
    notes: "Tri-amplified 3-way studio monitor featuring SPOC and MEME technology in ported cabinet"
  },
  {
    id: "hedd-type-20",
    brand: "HEDD",
    model: "Type 20",
    category: "studio-monitor",
    year: 2017,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 3,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 32,
      high_hz: 50000,
      status: "MANUFACTURER_VERIFIED",
      source: "HEDD Audio Technical Specifications (32Hz - 50kHz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 900,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "HEDD ICEpower: 3 x 300W Class-D amplifiers",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 7,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "HEDD 7 inch honeycomb woofer + 4 inch honeycomb midrange + HEDD Air Motion Transformer",
      sourceType: "MANUFACTURER"
    },
    notes: "Active 3-way nearfield/midfield studio monitor with Klaus Heinz AMT transformer"
  },
  {
    id: "ik-multimedia-iloud-mtm",
    brand: "IK Multimedia",
    model: "iLoud MTM",
    category: "studio-monitor",
    year: 2019,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 3,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 40,
      high_hz: 24000,
      status: "MANUFACTURER_VERIFIED",
      source: "IK Multimedia iLoud MTM Specifications (40Hz - 24kHz @ -3dB)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 100,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "IK Multimedia Bi-amped Class-D: 70W LF + 30W HF RMS",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 3.5,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "2 x 3.5 inch custom polypropylene mid-woofers + 1 inch back-chambered silk dome",
      sourceType: "MANUFACTURER"
    },
    notes: "Compact symmetric MTM (D'Appolito) active studio monitor with built-in ARC acoustic calibration"
  },
  {
    id: "focal-trio11-be",
    brand: "Focal",
    model: "Trio11 Be",
    category: "studio-monitor",
    year: 2019,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 3,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 30,
      high_hz: 40000,
      status: "MANUFACTURER_VERIFIED",
      source: "Focal Professional Tech Specs: 3-way 30Hz - 40kHz (+/-3dB), 2-way FOCUS mode 90Hz - 20kHz",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 450,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "Focal Amplification: Subwoofer 300W Class G, Midrange 100W Class G, Tweeter 50W Class AB",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 10,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Focal 10 inch W-cone subwoofer + 5 inch W-cone midrange + 1 inch pure Beryllium inverted dome",
      sourceType: "MANUFACTURER"
    },
    notes: "High-power dual-monitor system with rotating midrange/tweeter baffle and Focus 2-way mode"
  },
  {
    id: "dutch-and-dutch-8c",
    brand: "Dutch & Dutch",
    model: "8c",
    category: "studio-monitor",
    year: 2018,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 4,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 30,
      high_hz: 20000,
      status: "MANUFACTURER_VERIFIED",
      source: "Dutch & Dutch 8c Specifications (30Hz - 20kHz +/-1dB)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 1000,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "Pascal Class-D: 500W Sub (rear), 250W Mid, 250W HF",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 8,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "2 x 8 inch rear subwoofers + 8 inch acoustic cardioid mid-woofer + 1 inch alloy dome tweeter in waveguide",
      sourceType: "MANUFACTURER"
    },
    notes: "Cardioid mid-frequency dispersion active DSP studio monitor with Boundary Matching Technology"
  },
  {
    id: "genelec-1032c",
    brand: "Genelec",
    model: "1032C",
    category: "studio-monitor",
    year: 2017,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 2,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 40,
      high_hz: 20000,
      status: "MANUFACTURER_VERIFIED",
      source: "Genelec 1032C Operating Manual (40Hz - 20kHz +/-2.5dB, -6dB 33Hz - 23kHz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 250,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "Genelec Class-D: 200W Woofer + 150W Tweeter (short term)",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 10,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Genelec 10 inch (250mm) woofer + 1 inch (25mm) metal dome tweeter + DCW",
      sourceType: "MANUFACTURER"
    },
    notes: "Active SAM nearfield/midfield studio monitor with Directivity Control Waveguide and GLM calibration"
  },
  {
    id: "revel-ultima-salon2",
    brand: "Revel",
    model: "Ultima Salon2",
    category: "floor-standing",
    year: 2007,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 6,
    active: false,
    panel: false,
    sensitivity: {
      value: 86.4,
      unit: "dB",
      status: "MANUFACTURER_VERIFIED",
      source: "Revel Ultima2 Specifications (86.4 dB SPL @ 2.83V/1m)",
      sourceType: "MANUFACTURER"
    },
    frequencyResponse: {
      low_hz: 23,
      high_hz: 45000,
      status: "MANUFACTURER_VERIFIED",
      source: "Revel Ultima2 Specifications (-3dB from 23Hz to 45kHz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 600,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "Revel Recommended amplifier power: 50 - 600 Watts",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: 6,
      unit: "ohm",
      status: "MANUFACTURER_VERIFIED",
      source: "Revel Specifications (6 ohms nominal, 3.7 ohms minimum at 29Hz)",
      sourceType: "MANUFACTURER"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 8,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Three 8 inch Titanium cone woofers + 6.5 inch Titanium mid-bass + 4 inch Titanium mid + 1 inch Beryllium tweeter",
      sourceType: "MANUFACTURER"
    },
    notes: "Flagship 4-way reference floorstanding loudspeaker with pure Beryllium dome tweeter"
  },
  {
    id: "magico-m2",
    brand: "Magico",
    model: "M2",
    category: "floor-standing",
    year: 2018,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 4,
    active: false,
    panel: false,
    sensitivity: {
      value: 88,
      unit: "dB",
      status: "MANUFACTURER_VERIFIED",
      source: "Magico LLC Official Specifications (88dB sensitivity)",
      sourceType: "MANUFACTURER"
    },
    frequencyResponse: {
      low_hz: 26,
      high_hz: 50000,
      status: "MANUFACTURER_VERIFIED",
      source: "Magico LLC Official Specifications (26Hz - 50kHz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 500,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "Magico Recommended Power: 50W min, 500W max",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: 4,
      unit: "ohm",
      status: "MANUFACTURER_VERIFIED",
      source: "Magico LLC Official Specifications (4 ohms nominal)",
      sourceType: "MANUFACTURER"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 7,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Two 7 inch Graphene Nano-Tec woofers + 6 inch Graphene midrange + 28mm diamond-coated Beryllium tweeter",
      sourceType: "MANUFACTURER"
    },
    notes: "Reference 3-way floorstanding speaker with carbon-fibre monocoque enclosure"
  },
  {
    id: "wilson-audio-alexia",
    brand: "Wilson Audio",
    model: "Alexia",
    category: "floor-standing",
    year: 2012,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 4,
    active: false,
    panel: false,
    sensitivity: {
      value: 90,
      unit: "dB",
      status: "MANUFACTURER_VERIFIED",
      source: "Wilson Audio Specialties Specifications (90dB @ 1W @ 1m @ 1k)",
      sourceType: "MANUFACTURER"
    },
    frequencyResponse: {
      low_hz: 20,
      high_hz: 32000,
      status: "MANUFACTURER_VERIFIED",
      source: "Wilson Audio Specialties Specifications (20Hz - 32kHz +/-3dB room average)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 300,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "Wilson Audio Minimum amplifier power: 20W/channel",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: 4,
      unit: "ohm",
      status: "MANUFACTURER_VERIFIED",
      source: "Wilson Audio Specifications (4 ohms nominal, 2.0 ohms minimum @ 80Hz)",
      sourceType: "MANUFACTURER"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 10,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "One 8.25 inch and one 10 inch paper pulp woofers + 7 inch cellulose/carbon midrange + 1 inch Convergent Synergy silk dome tweeter",
      sourceType: "MANUFACTURER"
    },
    notes: "Modular reference floorstanding speaker with Aspherical time-domain alignment"
  },
  {
    id: "jbl-hdi-3800",
    brand: "JBL",
    model: "HDI-3800",
    category: "floor-standing",
    year: 2020,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 4,
    active: false,
    panel: false,
    sensitivity: {
      value: 92,
      unit: "dB",
      status: "MANUFACTURER_VERIFIED",
      source: "JBL Synthesis HDI-3800 Spec Sheet (92dB @ 2.83V/1m)",
      sourceType: "MANUFACTURER"
    },
    frequencyResponse: {
      low_hz: 37,
      high_hz: 30000,
      status: "MANUFACTURER_VERIFIED",
      source: "JBL Synthesis HDI-3800 Spec Sheet (37Hz - 30kHz +/-3dB, -6dB at 37Hz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 300,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "JBL Recommended Amplifier Power: 25W - 300W",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: 4,
      unit: "ohm",
      status: "MANUFACTURER_VERIFIED",
      source: "JBL Synthesis HDI-3800 Spec Sheet (4 ohms nominal)",
      sourceType: "MANUFACTURER"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: 1.5,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "JBL 1.5 inch voice coils on 8 inch aluminium cone woofers",
      sourceType: "MANUFACTURER"
    },
    woofer: {
      value: 8,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Triple 8 inch (200mm) black aluminium matrix cone woofers + 1 inch 2410H-2 Teonex compression driver in HDI waveguide",
      sourceType: "MANUFACTURER"
    },
    notes: "Flagship 2.5-way floorstanding loudspeaker with High-Definition Imaging waveguide"
  },
  {
    id: "kef-r7",
    brand: "KEF",
    model: "R7",
    category: "floor-standing",
    year: 2018,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 3,
    active: false,
    panel: false,
    sensitivity: {
      value: 88,
      unit: "dB",
      status: "MANUFACTURER_VERIFIED",
      source: "KEF R Series Specifications (88dB @ 2.83V/1m)",
      sourceType: "MANUFACTURER"
    },
    frequencyResponse: {
      low_hz: 33,
      high_hz: 50000,
      status: "MANUFACTURER_VERIFIED",
      source: "KEF R Series Specifications (-6dB 33Hz - 50kHz, typical in-room bass response 27Hz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 250,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "KEF Recommended amplifier power: 15 - 250W",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: 8,
      unit: "ohm",
      status: "MANUFACTURER_VERIFIED",
      source: "KEF R Series Specifications (8 ohms nominal, 3.2 ohms minimum)",
      sourceType: "MANUFACTURER"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 6.5,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Two 6.5 inch (165mm) hybrid aluminium bass drivers + Uni-Q array (5 inch MF / 1 inch vented HF)",
      sourceType: "MANUFACTURER"
    },
    notes: "Mid-sized 3-way floorstanding speaker with 12th generation Uni-Q driver array (pre-Meta)"
  },
  {
    id: "meyer-sound-upj-1p",
    brand: "Meyer Sound",
    model: "UPJ-1P",
    category: "pa",
    year: 2004,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 2,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 55,
      high_hz: 20000,
      status: "MANUFACTURER_VERIFIED",
      source: "Meyer Sound UPJ-1P Operating Instructions (55Hz - 20kHz +/-4dB, 66Hz - 18kHz +/-2dB)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 300,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "Meyer Sound 2-channel Class AB/bridged MOSFET amplifier: 300W total",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 10,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Meyer Sound 10 inch cone driver + 3 inch diaphragm / 2 inch throat compression driver on rotatable VariO horn",
      sourceType: "MANUFACTURER"
    },
    notes: "Compact self-powered professional sound reinforcement loudspeaker with rotatable 80x50 VariO horn"
  },
  {
    id: "meyer-sound-leopard",
    brand: "Meyer Sound",
    model: "LEOPARD",
    category: "pa",
    year: 2015,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 3,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 55,
      high_hz: 18000,
      status: "MANUFACTURER_VERIFIED",
      source: "Meyer Sound LEOPARD Datasheet (55Hz - 18kHz +/-4dB)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 900,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "Meyer Sound 3-channel Class D amplifier",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 9,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Two 9 inch long-excursion cone drivers + one 3 inch diaphragm compression driver with REM manifold",
      sourceType: "MANUFACTURER"
    },
    notes: "Compact linear self-powered line array loudspeaker with 110-degree horizontal coverage"
  },
  {
    id: "meyer-sound-lina",
    brand: "Meyer Sound",
    model: "LINA",
    category: "pa",
    year: 2017,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 3,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 65,
      high_hz: 18000,
      status: "MANUFACTURER_VERIFIED",
      source: "Meyer Sound LINA Operating Instructions (65Hz - 18kHz +/-4dB)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 600,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "Meyer Sound 3-channel Class D amplifier",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 6.5,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Two 6.5 inch cone drivers + one 3 inch diaphragm compression driver on REM manifold",
      sourceType: "MANUFACTURER"
    },
    notes: "Very compact linear line array loudspeaker for high intelligibility sound reinforcement"
  },
  {
    id: "qsc-kw122",
    brand: "QSC",
    model: "KW122",
    category: "pa",
    year: 2010,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 2,
    active: true,
    panel: false,
    sensitivity: {
      value: null,
      unit: "dB",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    frequencyResponse: {
      low_hz: 50,
      high_hz: 20000,
      status: "MANUFACTURER_VERIFIED",
      source: "QSC KW Series User Manual (50Hz - 20kHz -10dB, 53Hz - 18kHz -6dB)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 1000,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "QSC Class D: 500W LF + 500W HF continuous (2000W peak)",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: null,
      unit: "ohm",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: null,
      unit: "in",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    woofer: {
      value: 12,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "12 inch cone transducer + 1.75 inch diaphragm compression driver",
      sourceType: "MANUFACTURER"
    },
    notes: "1000W continuous 12-inch 2-way active wooden enclosure loudspeaker with DMT waveguide"
  },
  {
    id: "electro-voice-x12-128",
    brand: "Electro-Voice",
    model: "X12-128",
    category: "subwoofer",
    year: 2015,
    overallStatus: "PARTIALLY_VERIFIED",
    driverCount: 2,
    active: false,
    panel: false,
    sensitivity: {
      value: 105,
      unit: "dB",
      status: "MANUFACTURER_VERIFIED",
      source: "Electro-Voice X-Line Advance X12-128 Engineering Data Sheet (105dB half-space 1W/1m)",
      sourceType: "MANUFACTURER"
    },
    frequencyResponse: {
      low_hz: 27,
      high_hz: 200,
      status: "MANUFACTURER_VERIFIED",
      source: "Electro-Voice X-Line Advance X12-128 Engineering Data Sheet (-10dB 27Hz - 200Hz, -3dB 33Hz - 200Hz)",
      sourceType: "MANUFACTURER"
    },
    power: {
      value: 4000,
      unit: "W",
      status: "MANUFACTURER_VERIFIED",
      source: "Electro-Voice Continuous power handling: 4000W (16000W peak)",
      sourceType: "MANUFACTURER"
    },
    impedance: {
      value: 4,
      unit: "ohm",
      status: "MANUFACTURER_VERIFIED",
      source: "Electro-Voice Dual 8 ohms nominal inputs / 4 ohms parallel (minimum 2 x 6.4 ohms)",
      sourceType: "MANUFACTURER"
    },
    resonantFreq: {
      value: null,
      unit: "Hz",
      status: "UNAVAILABLE",
      source: null,
      sourceType: "NONE"
    },
    voiceCoil: {
      value: 4,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Electro-Voice 4 inch voice coil on DVF4180 woofers",
      sourceType: "MANUFACTURER"
    },
    woofer: {
      value: 18,
      unit: "in",
      status: "MANUFACTURER_VERIFIED",
      source: "Dual 18 inch Electro-Voice DVF4180 high-output woofers",
      sourceType: "MANUFACTURER"
    },
    notes: "High-output dual 18-inch concert line array subwoofer system capable of 147dB peak SPL"
  }
];

let issues = 0;
for (const c of CANDIDATES) {
  if (existingIds.has(c.id)) {
    console.error("Duplicate ID conflict:", c.id);
    issues++;
  }
  const pair = `${c.brand.toLowerCase()}|${c.model.toLowerCase()}`;
  if (existingPairs.has(pair)) {
    console.error("Duplicate Brand/Model pair:", pair);
    issues++;
  }
}

if (issues === 0) {
  console.log(`ALL ${CANDIDATES.length} CANDIDATES ARE CLEAN AND UNIQUE.`);
}
