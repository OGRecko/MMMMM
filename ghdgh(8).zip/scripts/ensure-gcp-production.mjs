import { execFileSync } from 'node:child_process';

const project = process.env.GCP_PROJECT_ID;
const region = process.env.CLOUD_RUN_REGION || 'us-central1';
const runtimeSa = process.env.CLOUD_RUN_SERVICE_ACCOUNT;
const queue = process.env.CLOUD_TASKS_QUEUE || 'cavity-solver';
const taskLocation = process.env.CLOUD_TASKS_LOCATION || region;
if (!project || !runtimeSa) throw new Error('GCP_PROJECT_ID and CLOUD_RUN_SERVICE_ACCOUNT are required');
if (!/^[a-z][a-z0-9-]{0,62}$/.test(project)) throw new Error('Invalid GCP_PROJECT_ID');
if (!/^[a-z][a-z0-9-]{0,62}$/.test(region)) throw new Error('Invalid CLOUD_RUN_REGION');
if (!/^[a-z][a-z0-9-]{0,62}$/.test(taskLocation)) throw new Error('Invalid CLOUD_TASKS_LOCATION');
if (!/^[a-z][a-z0-9-]{0,99}$/.test(queue)) throw new Error('Invalid CLOUD_TASKS_QUEUE');

function gcloud(args, options = {}) {
  return execFileSync('gcloud', args, { encoding: 'utf8', stdio: ['ignore', options.capture ? 'pipe' : 'inherit', 'pipe'] });
}

gcloud(['services', 'enable', 'run.googleapis.com', 'artifactregistry.googleapis.com', 'cloudbuild.googleapis.com', 'cloudtasks.googleapis.com', 'firestore.googleapis.com', 'storage.googleapis.com', 'firebase.googleapis.com', `--project=${project}`]);
try { gcloud(['tasks', 'queues', 'describe', queue, `--location=${taskLocation}`, `--project=${project}`, '--format=json']); }
catch { gcloud(['tasks', 'queues', 'create', queue, `--location=${taskLocation}`, `--project=${project}`]); }

// Cloud Run deployment requires the identity executing `gcloud run deploy` to
// impersonate/act as the runtime service account. Grant only the standard
// Service Account User role on that one runtime identity. This is separate
// from the runtime service account's own project roles below.
const activeAccount = gcloud(['auth', 'list', '--filter=status:ACTIVE', '--format=value(account)'], { capture: true }).trim();
if (!activeAccount) throw new Error('No active gcloud deployment identity found.');
const deployerMember = activeAccount.endsWith('.gserviceaccount.com')
  ? `serviceAccount:${activeAccount}`
  : `user:${activeAccount}`;
gcloud(['iam', 'service-accounts', 'add-iam-policy-binding', runtimeSa, `--member=${deployerMember}`, '--role=roles/iam.serviceAccountUser', `--project=${project}`, '--condition=None', '--quiet']);
console.log(`ENSURED roles/iam.serviceAccountUser for ${deployerMember} on ${runtimeSa}`);

const member = `serviceAccount:${runtimeSa}`;
for (const role of ['roles/datastore.user', 'roles/storage.objectAdmin', 'roles/cloudtasks.enqueuer', 'roles/logging.logWriter']) {
  gcloud(['projects', 'add-iam-policy-binding', project, `--member=${member}`, `--role=${role}`, '--condition=None', '--quiet']);
  console.log(`ENSURED ${role} for ${runtimeSa}`);
}

try { gcloud(['artifacts', 'repositories', 'describe', 'cavity', `--location=${region}`, `--project=${project}`]); }
catch { gcloud(['artifacts', 'repositories', 'create', 'cavity', '--repository-format=docker', `--location=${region}`, `--project=${project}`]); }
console.log(`GCP production infrastructure ready: ${project}, Cloud Run ${region}, Tasks ${taskLocation}/${queue}`);
