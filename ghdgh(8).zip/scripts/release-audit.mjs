import fs from 'node:fs'; import path from 'node:path';
const root=process.cwd(); const problems=[]; const warnings=[];
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
const lim=read('src/lib/publicLimits.ts');
if(!/MAX_GRID_CELLS:\s*50_000_000/.test(lim)) problems.push('50M public grid cap missing');
const data=JSON.parse(read('src/data/speakers.json')); const ids=new Set(); const names=new Set();
if(data.length!==774) problems.push(`speaker count changed: expected 774, found ${data.length}`);
const legacyCount=data.filter(s=>s?.overallStatus==='LEGACY').length;
if(legacyCount!==80) problems.push(`legacy speaker count changed: expected 80, found ${legacyCount}`);
const nonLegacyCount=data.filter(s=>s?.overallStatus!=='LEGACY').length;
if(nonLegacyCount!==694) problems.push(`non-legacy speaker count changed: expected 694, found ${nonLegacyCount}`);
for(const s of data){
  if(!s?.id||ids.has(s.id)) problems.push(`duplicate/missing speaker id: ${s?.id}`);
  ids.add(s.id);
  const k=`${s.brand}::${s.model}`.toLowerCase();
  if(names.has(k)) problems.push(`duplicate brand/model: ${s.brand} ${s.model}`);
  names.add(k);
  if(!['LEGACY','FULLY_VERIFIED','PARTIALLY_VERIFIED','MEASUREMENT_VERIFIED','UNAVAILABLE'].includes(s?.overallStatus)) problems.push(`invalid overallStatus: ${s?.id}`);
  for(const field of ['sensitivity','power','impedance','resonantFreq','voiceCoil','woofer']){
    const v=s?.[field]?.value;
    if(v!==null && v!==undefined && (typeof v!=='number' || !Number.isFinite(v) || v<=0)) problems.push(`invalid ${field} for ${s?.id}`);
  }
  if(s.sensitivity?.status==='MANUFACTURER_VERIFIED' && (!s.sensitivity.source || s.sensitivity.sourceType!=='MANUFACTURER')) warnings.push(`speaker sensitivity claims manufacturer verification without reproducible URL: ${s.brand} ${s.model}`);
}
console.log(JSON.stringify({ok:problems.length===0, filesChecked:data.length, duplicateIds:data.length-ids.size, duplicateBrandModels:data.length-names.size, problems, warnings:warnings.slice(0,25), warningCount:warnings.length},null,2));
process.exitCode=problems.length?1:0;
