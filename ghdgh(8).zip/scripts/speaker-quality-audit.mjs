/**
 * Comprehensive speaker database data quality audit script.
 * Scans src/data/speakers.json and evaluates data consistency, uniqueness,
 * categorization, ranges, and response curve / directivity coverage.
 */
import fs from 'node:fs';
import path from 'node:path';
import { KNOWN_SPEAKER_CURVES } from '../src/lib/speakerResponse.ts';

const root = process.cwd();
const data = JSON.parse(fs.readFileSync(path.join(root, 'src/data/speakers.json'), 'utf8'));

const ids = new Set();
const duplicateIds = [];
const brandModelPairs = new Set();
const duplicateBrandModels = [];

let missingBrand = 0;
let missingModel = 0;
let invalidCategories = 0;
let invalidFrequencyRanges = 0;
let invalidSensitivity = 0;
let invalidImpedance = 0;
let invalidPower = 0;
let invalidMaxSpl = 0;

let responseCurvesExplicit = 0;
let responseCurvesKnown = 0;
let directivityPresent = 0;

const statusCounts = {
  FULLY_VERIFIED: 0,
  PARTIALLY_VERIFIED: 0,
  MEASUREMENT_VERIFIED: 0,
  LEGACY: 0,
  UNAVAILABLE: 0,
  OTHER: 0
};

const VALID_CATEGORIES = new Set([
  'studio-monitor',
  'floor-standing',
  'bookshelf',
  'pa',
  'subwoofer',
  'ceiling',
  'in-wall',
  'portable',
  'guitar-cab',
  'car-audio',
  'soundbar',
  'smart-speaker',
  'hifi',
  'cinema',
  'custom'
]);

for (const s of data) {
  // 1. ID check
  if (!s.id || typeof s.id !== 'string') {
    duplicateIds.push(String(s.id));
  } else if (ids.has(s.id)) {
    duplicateIds.push(s.id);
  } else {
    ids.add(s.id);
  }

  // 2. Brand & Model
  if (!s.brand || typeof s.brand !== 'string' || s.brand.trim() === '') missingBrand++;
  if (!s.model || typeof s.model !== 'string' || s.model.trim() === '') missingModel++;

  const pairKey = `${(s.brand || '').trim()}::${(s.model || '').trim()}`.toLowerCase();
  if (brandModelPairs.has(pairKey)) {
    duplicateBrandModels.push(`${s.brand} ${s.model}`);
  } else {
    brandModelPairs.add(pairKey);
  }

  // 3. Category
  if (!VALID_CATEGORIES.has(s.category)) {
    invalidCategories++;
  }

  // 4. Frequency range
  if (s.frequencyResponse) {
    const low = s.frequencyResponse.low_hz;
    const high = s.frequencyResponse.high_hz;
    if (low !== null && (typeof low !== 'number' || !Number.isFinite(low) || low <= 0 || low > 20000)) {
      invalidFrequencyRanges++;
    }
    if (high !== null && (typeof high !== 'number' || !Number.isFinite(high) || high < 50 || high > 100000)) {
      invalidFrequencyRanges++;
    }
    if (low !== null && high !== null && low >= high) {
      invalidFrequencyRanges++;
    }
    if (s.frequencyResponse.points && Array.isArray(s.frequencyResponse.points) && s.frequencyResponse.points.length >= 2) {
      responseCurvesExplicit++;
    }
  }

  if (KNOWN_SPEAKER_CURVES && KNOWN_SPEAKER_CURVES[s.id]) {
    responseCurvesKnown++;
  }

  // 5. Sensitivity
  if (s.sensitivity && s.sensitivity.value !== null) {
    const val = s.sensitivity.value;
    if (typeof val !== 'number' || !Number.isFinite(val) || val < 50 || val > 140) {
      invalidSensitivity++;
    }
  }

  // 6. Impedance
  if (s.impedance && s.impedance.value !== null) {
    const val = s.impedance.value;
    if (typeof val !== 'number' || !Number.isFinite(val) || val < 1 || val > 100) {
      invalidImpedance++;
    }
  }

  // 7. Power
  if (s.power && s.power.value !== null) {
    const val = s.power.value;
    if (typeof val !== 'number' || !Number.isFinite(val) || val <= 0 || val > 50000) {
      invalidPower++;
    }
  }

  // 8. Max SPL
  if (s.maxSpl && s.maxSpl.value !== null) {
    const val = s.maxSpl.value;
    if (typeof val !== 'number' || !Number.isFinite(val) || val < 70 || val > 170) {
      invalidMaxSpl++;
    }
  }

  // 9. Directivity
  if (s.directivity && (s.directivity.h_beamwidth || s.directivity.v_beamwidth || s.directivity.q)) {
    directivityPresent++;
  }

  // 10. Status
  const st = s.overallStatus;
  if (st && statusCounts[st] !== undefined) {
    statusCounts[st]++;
  } else {
    statusCounts.OTHER++;
  }
}

const auditResult = {
  totalSpeakers: data.length,
  uniqueIds: ids.size,
  duplicateIdsCount: duplicateIds.length,
  duplicateIds,
  uniqueBrandModelPairs: brandModelPairs.size,
  duplicateBrandModelsCount: duplicateBrandModels.length,
  duplicateBrandModels,
  missingBrand,
  missingModel,
  invalidCategories,
  invalidFrequencyRanges,
  invalidSensitivity,
  invalidImpedance,
  invalidPower,
  invalidMaxSpl,
  responseCurves: {
    explicitCurvePointsInJson: responseCurvesExplicit,
    verifiedLibraryCurves: responseCurvesKnown,
    physicallyModeledCoverage: data.length - responseCurvesExplicit - responseCurvesKnown,
    totalCoverage: data.length
  },
  directivity: {
    explicitPolarDataPresent: directivityPresent,
    fallbackApproximation: data.length - directivityPresent
  },
  verificationBreakdown: statusCounts,
  malformedRecords: duplicateIds.length + duplicateBrandModels.length + missingBrand + missingModel + invalidCategories + invalidFrequencyRanges
};

console.log(JSON.stringify(auditResult, null, 2));

if (auditResult.malformedRecords > 0) {
  console.error(`Audit found ${auditResult.malformedRecords} malformed/inconsistent records!`);
  process.exit(1);
} else {
  console.log(`Audit PASSED: All ${data.length} records verified.`);
}
