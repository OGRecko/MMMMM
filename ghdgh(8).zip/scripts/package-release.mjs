/**
 * Creates the official release zip for Cavity Audio.
 * Gathers all source files, configurations, scripts, workflows, and tests
 * while strictly excluding build artifacts (dist), dependencies (node_modules),
 * and runtime caches.
 */
import fs from 'node:fs';
import path from 'node:path';
import { zipSync } from 'fflate';

const ROOT_DIR = process.cwd();
const OUTPUT_ZIP = path.join(ROOT_DIR, 'cavity-v3.1.0-release.zip');

const EXCLUDED_DIRS = new Set([
  'node_modules',
  'dist',
  '.git',
  '.vite',
  '.cache',
]);

const EXCLUDED_FILES = new Set([
  'cavity-v3.1.0-release.zip',
  '.DS_Store',
]);

function collectFiles(dir, relativePrefix = '') {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const result = {};

  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relPath = relativePrefix ? `${relativePrefix}/${entry.name}` : entry.name;

    if (entry.isDirectory()) {
      if (EXCLUDED_DIRS.has(entry.name)) continue;
      Object.assign(result, collectFiles(fullPath, relPath));
    } else if (entry.isFile()) {
      if (EXCLUDED_FILES.has(entry.name) || entry.name.endsWith('.zip')) continue;
      const content = fs.readFileSync(fullPath);
      result[relPath] = content;
    }
  }

  return result;
}

console.log('Collecting project files for release ZIP...');
const files = collectFiles(ROOT_DIR);
const fileCount = Object.keys(files).length;
console.log(`Collected ${fileCount} files.`);

console.log('Compressing into ZIP archive...');
const zipBuffer = zipSync(files, { level: 9 });

fs.writeFileSync(OUTPUT_ZIP, zipBuffer);
const publicZip = path.join(ROOT_DIR, 'public', 'cavity-v3.1.0-release.zip');
fs.writeFileSync(publicZip, zipBuffer);
const sizeMb = (zipBuffer.byteLength / (1024 * 1024)).toFixed(2);
console.log(`Created release archive: ${OUTPUT_ZIP} and ${publicZip} (${sizeMb} MB, ${fileCount} files)`);
