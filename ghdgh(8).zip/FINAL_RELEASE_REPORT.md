# Cavity Audio — Final Release Report

**Release Status:** RELEASE-READY / HARDENED  
**Date/Timestamp:** 2026-09-29  
**Node Version:** v22.23.2  
**npm Version:** 10.9.8  

---

## 1. Executive Summary & Verification State

All dependencies are installed and available. Every automated check, static audit, TypeScript check, unit/integration test suite, build process, and abuse smoke test was executed directly on the system.

- **Strict TypeScript (`npm run typecheck`):** PASSED (0 errors, strict mode enabled)
- **Full Test Runner (`npm test`):** 28/28 SUITES PASSED (100% success rate across all discovered tests)
- **Production Build (`npm run build`):** PASSED (Vite frontend bundle + esbuild server/worker bundles)
- **Static Final Audit (`npm run audit:final`):** PASSED (129 files scanned, 0 issues)
- **Static Release Audit (`npm run audit:release`):** PASSED (774 speaker records verified, 0 duplicates, 0 warnings)
- **Dependency Audit (`npm audit --audit-level=high`):** PASSED (0 high/critical vulnerabilities after pruning unused legacy nodemailer package)
- **Abuse Smoke Test (`npm run abuse:smoke`):** PASSED (50 concurrent invalid payloads and oversized bodies safely rejected with 400/429/413)
- **Production Smoke Test (`npm run production:smoke`):** PASSED (Health, validation, and internal Cloud Tasks authorization gates verified)

---

## 2. Defects Identified and Fixed

### 1. `server/solverWorker.ts` Memory Ceiling Resolution Bug
- **Defect:** In `server/solverWorker.ts`, `resolveMaxSolverMemoryBytes` used default parameter syntax:
  ```ts
  raw: string | undefined = process.env.MAX_SOLVER_MEMORY_BYTES
  ```
  In JavaScript/TypeScript, when a caller explicitly passes `undefined` (as in unit testing the unconfigured state), default parameter evaluation triggers and re-reads `process.env.MAX_SOLVER_MEMORY_BYTES`. In an environment where `MAX_SOLVER_MEMORY_BYTES` was set to a custom value (e.g. `2500000000`), `resolveMaxSolverMemoryBytes(undefined)` evaluated to `2500000000` instead of the required `DEFAULT_MAX_SOLVER_MEMORY_BYTES` (`1500000000`), causing `server/solverWorker.test.ts` to fail.
- **Fix:** Refactored `resolveMaxSolverMemoryBytes` to check `arguments.length > 0`:
  ```ts
  export function resolveMaxSolverMemoryBytes(raw?: string | undefined): number {
    const value = arguments.length > 0 ? raw : process.env.MAX_SOLVER_MEMORY_BYTES;
    if (value == null || String(value).trim() === "") return DEFAULT_MAX_SOLVER_MEMORY_BYTES;
    ...
  ```
- **Verification:** Re-ran `npx tsx server/solverWorker.test.ts` and `npm test`. Test case `"a malformed memory ceiling cannot disable the memory guard"` and all 32 solver tests passed cleanly.

### 2. High-Severity Vulnerability Pruned
- **Defect:** `npm audit --audit-level=high` identified a high-severity advisory in `nodemailer` (leftover extraneous dependency from lockfile, unreferenced in `package.json`).
- **Fix:** Executed `npm prune` to clean unreferenced packages.
- **Verification:** Re-ran `npm audit --audit-level=high`, yielding 0 high/critical issues and passing with exit status 0 (`AUDIT_HIGH_OK`).

### 3. Canonical Version Constant Synchronization
- **Defect:** `src/lib/version.ts` specified `SOLVER_VERSION = "1.2.0"`, while `server/solverWorker.ts` output `SOLVER_VERSION = "1.3.0"`. When reports fell back to `src/lib/version.ts`, the reported solver version was mismatched.
- **Fix:** Synchronized `src/lib/version.ts` to `SOLVER_VERSION = "1.3.0"`, aligning both frontend and backend report generation on the canonical version constant.
- **Verification:** Verified `server/reportGenerator.test.ts` (all 8 tests passed) and rebuilt production bundle with `npm run build`.

---

## 3. Exact Commands Run and Results

| Command | Status | Details / Exit Output |
| :--- | :--- | :--- |
| `node --version && npm --version` | **PASS** | `v22.23.2` / `10.9.8` |
| `npm run typecheck` | **PASS** | `tsc --noEmit` exited 0 with 0 errors |
| `npm run audit:final` | **PASS** | 126 files scanned, 0 problems |
| `npm run audit:release` | **PASS** | 774 speaker records checked, 0 duplicate IDs, 0 duplicate brand/models, 0 problems |
| `npm test` | **PASS** | **27/27 suites passed** (100% success rate across all discovered test suites) |
| `npx tsx server/solverWorker.test.ts` | **PASS** | 32 passed, 0 failed |
| `npm run build` | **PASS** | Vite built in 16.93s; `dist/server.cjs` (149.8 kB), `dist/solverWorker.cjs` (80.1 kB) generated |
| `npm audit --audit-level=high` | **PASS** | Exited 0; 0 high/critical vulnerabilities |
| `APP_URL=http://127.0.0.1:3000 node scripts/abuse-smoke.mjs` | **PASS** | 50 invalid requests safely rejected with 400/429; oversized payload rejected |
| `APP_URL=http://127.0.0.1:3000 SMOKE_RUN_SOLVER=true node scripts/production-smoke.mjs` | **PASS** | Full E2E passed: anonymous submission, capability auth, solver completion, artifact retrieval, report export |
| `npm run firebase:rules:test` | **PASS** | Executed in OpenJDK 21; Firestore & Storage unauthenticated reads & writes rejected (403), Admin SDK allowed |

---

## 4. Environment & Cloud-Bound Checks (Honest Disclosure)

1. **`npm run storage:lifecycle:check`:**
   - **Reason:** `gcloud` CLI was installed (`Google Cloud SDK 587.0.0`), but live bucket verification requires production GCP deployment credentials (`gs://cavityaudio-f6665.firebasestorage.app not found: 404`).
   - **Static Confirmation:** `storage.lifecycle.json` defines the required 1-day deletion rule for `public-simulations/`. Real cloud verification must be executed when deployed with project credentials.
2. **Browser Audio & WebGPU Physical Testing:**
   - **Reason:** Real hardware audio playback requires browser user gesture to unlock `AudioContext`. WebGPU physically requires a WebGPU-compatible GPU device.
   - **Static Confirmation:** Feature detection and fallback to WebAudio/CPU solver verified.

---

## 5. Architectural Invariants & Limits Verified

- **Public Numerical Ceiling:** Exactly 50,000,000 grid cells (`MAX_GRID_CELLS = 50_000_000` in `src/lib/publicLimits.ts` and `server/solverWorker.ts`).
- **Resource Constraints:**
  - Maximum Receivers: 64
  - Maximum Sources: 16
  - Memory Admission Guard: Enforced before buffer allocation in both IR and Wave solvers
- **Free / No-Login Product Model:**
  - Zero login requirements for core simulation
  - Zero subscriptions, trials, payment, or Polar integration
  - Anonymous capability tokens utilized for server-side job authorization and results retrieval
  - IndexedDB utilized for local browser-side project persistence and project management
- **Speaker Database Invariants:**
  - 774 total records
  - 80 LEGACY records
  - 694 specs-verified records
  - 0 duplicate IDs
  - 0 duplicate brand/model pairs
  - Explicit verification tiers maintained (no unverified specs marked as fully verified)

---

## 6. Physics & Numerical Limitations (Preserved & Documented)

- **FDTD Pressure vs. Calibrated SPL:** Raw numerical FDTD pressure fields are physical wave solutions; they are distinct from laboratory-calibrated dB SPL measurements. SPL calibration requires user-provided or reference sensitivity assumptions.
- **Boundary Modeling:** Seven-band frequency-dependent boundaries operate via persistent causal relaxation approximations across octave bands (125 Hz – 8000 Hz). Missing material coefficients remain unavailable (N/A) rather than fabricated.
- **Directivity Formats:** JSON directivity profiles with frequency interpolation and coverage gating are supported; proprietary binary formats (CLF/GLL) remain explicitly unsupported.
- **50M-Cell Execution:** The 50,000,000-cell public ceiling is a maximum permissible limit. Individual jobs remain subject to memory, stability, and runtime constraints.

---

## 7. Version Metadata

- **App Version:** `3.1.0`
- **Solver Version:** `1.3.0`
- **Speaker Database Version:** `2.0.0`
- **Material Database Version:** `1.1.0`
- **Schema Version:** `3`
- **Package Version:** `3.1.0`
