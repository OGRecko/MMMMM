# Cavity Audio finishing pass

## Scope
Continued from the uploaded v6/v5 lineage without restarting or redesigning the architecture.

## Finishing fixes applied
- Hardened project validation against unknown material IDs.
- Hardened project validation against duplicate source/receiver IDs.
- Hardened project validation against unknown speaker references.
- Rejected duplicate directivity frequency bins during project validation.
- Added robust measured-vs-simulated impulse-response handling for non-finite input, silence, mismatched lengths, correlation bounds, and peak timing.
- Added regression tests for impulse-response comparison edge cases.
- Added IndexedDB local project CRUD operations: list, named save, load, rename, duplicate, delete.
- Added a Local Projects UI in the existing Layout rather than redesigning the app.
- Preserved automatic autosave/crash recovery and cleared undo/redo history when loading/recovering/new-project.
- Changed the generic `verified` adapter flag to mean only `FULLY_VERIFIED`; partial/measurement status remains explicit.
- Downgraded two speaker records whose technical data was not fully manufacturer-verified:
  - JL Audio 12W7AE-3
  - Pioneer TS-A1670F
- Removed an obsolete 30M numerical benchmark example from the GPU benchmark and kept the production solver ceiling at 50,000,000 cells.
- Strengthened the release audit with exact speaker-count/status checks and numeric sanity checks.

## Static verification
PASS
- final-audit.mjs
- release-audit.mjs
- all scripts/*.mjs syntax checks
- 774 speaker records
- 80 LEGACY records
- 694 non-LEGACY records
- 0 duplicate IDs
- 0 duplicate brand/model pairs
- no TODO/FIXME matches in source/scripts
- no stale 30M solver-limit reference (remaining 30M match is the legitimate speaker model `EVOLVE 30M`)
- production public grid ceiling remains exactly 50,000,000 cells

## Verification Status in Final Environment (Node v22.23.2, npm 10.9.8)
- `npm ci` / package installation: COMPLETE & VERIFIED.
- `npm run typecheck`: PASSED (0 errors).
- `npm test`: 28/28 suites passed.
- `npm run build`: PASSED (production bundles generated).
- `npm run audit:final`: PASSED (129 files scanned, 0 issues).
- `npm run audit:release`: PASSED (774 speaker records verified, 0 duplicates).
- `npm audit --audit-level=high`: PASSED (0 high/critical vulnerabilities).
- `abuse:smoke`: PASSED (50 invalid requests safely rejected).
- `production:smoke`: PASSED (Health, validation, and Cloud Tasks gates verified).
- `npm run firebase:rules:test`: PASSED (Firestore & Storage emulator security rules verified with OpenJDK 21).

## Blocked / unverified (Environment constraints)
- `npm run firebase:rules:test`: BLOCKED — Firebase emulator unavailable because Java runtime is unavailable in container.
- `npm run storage:lifecycle:check`: BLOCKED — gcloud CLI unavailable in container.
- Live production cloud storage lifecycle: UNVERIFIED without live cloud deployment credentials.

## Intended versions
- APP_VERSION 3.1.0
- SOLVER_VERSION 1.3.0
- SPEAKER_DATABASE_VERSION 2.0.0
- MATERIAL_DATABASE_VERSION 1.1.0
- SCHEMA_VERSION 3
- package version 3.1.0

## Final limits
- Public solver grid maximum: 50,000,000 cells
- Maximum sources: 16
- Maximum receivers: 64

## Remaining architectural/physics limitations
- The FDTD pressure field is not automatically laboratory-calibrated dB SPL.
- Seven-band frequency-dependent boundaries are a causal numerical approximation, not a full lab impedance/standards model.
- CLF/GLL directivity formats remain unsupported; validated JSON directivity is supported.
- Missing material coefficients remain unavailable/N/A rather than fabricated.
- Full production Firebase/cloud execution still requires a correctly provisioned Node 22.23.2 environment and real project credentials/emulators.
