/**
 * Regression tests for 50,000,000 grid cell safety and pre-allocation guards.
 *
 * Verifies that the public numerical ceiling of 50M cells and memory budgets
 * are strictly enforced BEFORE allocating arrays across wave and IR solvers.
 */
import assert from "node:assert/strict";
import { runWave, runIR } from "./solverWorker.js";
import { LIMITS, waveGridRequirement } from "../src/lib/publicLimits.js";

let passed = 0;
const check = (name: string, fn: () => void) => {
  fn();
  passed++;
  console.log(`  PASS  ${name}`);
};

console.log("\n=== 50M Grid Ceiling & Pre-Allocation Safety Tests ===\n");

check("LIMITS.MAX_GRID_CELLS is exactly 50,000,000", () => {
  assert.equal(LIMITS.MAX_GRID_CELLS, 50_000_000);
});

check("waveGridRequirement computes correct elements for standard room", () => {
  const req = waveGridRequirement({ L: 6, W: 4, H: 2.8 }, 200, "balanced");
  assert(req.requiredElements > 0 && req.requiredElements < 50_000_000);
});

check("oversized wave simulation (> 50M cells) requires reduced resolution confirmation", () => {
  // A large hall at high Fmax and fine accuracy requires > 50M elements
  assert.throws(
    () => {
      runWave({
        L: 50, W: 40, H: 20,
        fmax: 800,
        accuracyMode: "high",
        confirmReducedResolution: false,
        source: { x: 0.5, y: 0.5, z: 1.5 },
        receiver: { x: 0.5, y: 0.5, z: 1.5 },
      });
    },
    (err: any) => {
      const msg = err.message || "";
      return msg.includes("requiresConfirmation") || msg.includes("exceeds the public safe limit");
    },
    "Expected confirmation requirement for grid requiring > 50M cells"
  );
});

check("oversized wave simulation with confirmReducedResolution clamps grid to <= 50,000,000", () => {
  const result = runWave({
    L: 40, W: 30, H: 10,
    fmax: 600,
    accuracyMode: "high",
    confirmReducedResolution: true,
    steps: 10,
    source: { x: 0.5, y: 0.5, z: 1.5 },
    receiver: { x: 0.5, y: 0.5, z: 1.5 },
  });
  assert(result.meshSize <= 50_000_000, `Grid size ${result.meshSize} exceeded 50,000,000`);
});

check("negative or non-finite dimensions are rejected before allocation", () => {
  assert.throws(() => {
    runWave({ L: -10, W: 4, H: 3, source: { x: 0.5, y: 0.5 }, receiver: { x: 0.5, y: 0.5 } });
  });
  assert.throws(() => {
    runWave({ L: NaN, W: 4, H: 3, source: { x: 0.5, y: 0.5 }, receiver: { x: 0.5, y: 0.5 } });
  });
  assert.throws(() => {
    runWave({ L: Infinity, W: 4, H: 3, source: { x: 0.5, y: 0.5 }, receiver: { x: 0.5, y: 0.5 } });
  });
  assert.throws(() => {
    runIR({ L: -10, W: 4, H: 3, source: { x: 0.5, y: 0.5 }, receiver: { x: 0.5, y: 0.5 } });
  });
  assert.throws(() => {
    runIR({ L: NaN, W: 4, H: 3, source: { x: 0.5, y: 0.5 }, receiver: { x: 0.5, y: 0.5 } });
  });
});

check("memory budget guard rejects excessive memory request before allocating arrays", () => {
  // Mock MAX_SOLVER_MEMORY_BYTES to a small threshold (e.g. 100 KB) and verify rejection
  const origEnv = process.env.MAX_SOLVER_MEMORY_BYTES;
  try {
    process.env.MAX_SOLVER_MEMORY_BYTES = "100000"; // 100 KB
    assert.throws(
      () => {
        runWave({
          L: 6, W: 4, H: 2.8,
          fmax: 200,
          accuracyMode: "balanced",
          confirmReducedResolution: true,
          source: { x: 0.5, y: 0.5, z: 1.5 },
          receiver: { x: 0.5, y: 0.5, z: 1.5 },
        });
      },
      (err: any) => err.message.includes("exceeds available system memory budget")
    );
  } finally {
    if (origEnv === undefined) delete process.env.MAX_SOLVER_MEMORY_BYTES;
    else process.env.MAX_SOLVER_MEMORY_BYTES = origEnv;
  }
});

console.log(`\n=== ${passed} passed, 0 failed ===\n`);
