/**
 * speakerAcousticDifference.test.ts
 *
 * Automated verification that every speaker produces genuinely distinct,
 * measurable acoustic outputs based on its physical/published response curves,
 * driver configuration, sensitivity, distance, and directivity.
 *
 * Verifies:
 * 1. Strict determinism: same speaker + same settings = identical output.
 * 2. Studio Monitor vs Subwoofer: massive measurable spectral differentiation.
 * 3. Yamaha NS-10M vs Flat Reference Monitor: presence-peak energy differentiation.
 * 4. Raw sensitivity vs Loudness-matched comparison behavior.
 * 5. Physical distance attenuation (1/r inverse distance law).
 * 6. Off-axis angle directivity attenuation.
 * 7. Logarithmic frequency interpolation numerical correctness.
 */

import { getSpeakerById, SPEAKER_SPECS } from './speakers';
import {
  simulateSpeakerDSP,
  getSpeakerResponseModel,
  interpolateLogFrequency,
  STANDARD_FREQUENCIES_HZ,
  type ResponsePoint
} from './speakerResponse';
import type { SpeakerSpec } from './speakerDSP';

console.log("\n=== Speaker Acoustic Difference & Real DSP Verification ===\n");

let passed = 0;
let failed = 0;
const failures: string[] = [];

function check(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  PASS  ${name}`);
  } catch (err: any) {
    failed++;
    failures.push(`${name}: ${err.message}`);
    console.log(`  FAIL  ${name}\n        ${err.message}`);
  }
}

function assert(cond: boolean, msg: string) {
  if (!cond) throw new Error(msg);
}

// Helpers
function generatePinkNoise(samples: number, sampleRate: number): Float32Array {
  const buf = new Float32Array(samples);
  let seed = 42;
  const lcg = () => {
    seed = (seed * 1664525 + 1013904223) % 4294967296;
    return seed / 2147483648 - 1.0;
  };

  let b0 = 0, b1 = 0, b2 = 0;
  for (let i = 0; i < samples; i++) {
    const white = lcg();
    b0 = 0.99765 * b0 + white * 0.099046;
    b1 = 0.96300 * b1 + white * 0.296516;
    b2 = 0.57000 * b2 + white * 1.052691;
    buf[i] = (b0 + b1 + b2 + white * 0.1848) * 0.15;
  }
  return buf;
}

function computeRms(signal: Float32Array): number {
  let sumSq = 0;
  for (let i = 0; i < signal.length; i++) {
    sumSq += signal[i] * signal[i];
  }
  return Math.sqrt(sumSq / signal.length);
}

function computeBandEnergy(signal: Float32Array, sampleRate: number, lowHz: number, highHz: number): number {
  // Simple discrete Fourier transform / filter-bank energy calculation for target band
  const N = Math.min(2048, signal.length);
  let totalEnergy = 0;
  const kMin = Math.floor((lowHz * N) / sampleRate);
  const kMax = Math.ceil((highHz * N) / sampleRate);

  for (let k = kMin; k <= kMax; k++) {
    let re = 0;
    let im = 0;
    const omega = (2 * Math.PI * k) / N;
    for (let n = 0; n < N; n++) {
      re += signal[n] * Math.cos(omega * n);
      im -= signal[n] * Math.sin(omega * n);
    }
    totalEnergy += (re * re + im * im) / (N * N);
  }
  return totalEnergy;
}

const sampleRate = 48000;
const testSignal = generatePinkNoise(48000 * 0.5, sampleRate); // 500 ms of deterministic pink noise

// -----------------------------------------------------------------------------
// Test 1: Determinism
// -----------------------------------------------------------------------------
check("Test 1: Same speaker + same input = bit-identical deterministic output", () => {
  const spec = getSpeakerById("yamaha-ns10m") as SpeakerSpec;
  assert(!!spec, "yamaha-ns10m must exist in database");

  const run1 = simulateSpeakerDSP(testSignal, sampleRate, spec, { loudnessMatched: true });
  const run2 = simulateSpeakerDSP(testSignal, sampleRate, spec, { loudnessMatched: true });

  assert(run1.length === run2.length, "Output lengths must match");
  let maxDiff = 0;
  for (let i = 0; i < run1.length; i++) {
    const diff = Math.abs(run1[i] - run2[i]);
    if (diff > maxDiff) maxDiff = diff;
  }
  assert(maxDiff === 0, `Deterministic runs must have 0 difference, got maxDiff ${maxDiff}`);
});

// -----------------------------------------------------------------------------
// Test 2: Studio Monitor vs Subwoofer
// -----------------------------------------------------------------------------
check("Test 2: Studio Monitor vs Subwoofer produces distinct measurable frequency distribution", () => {
  const monitor = getSpeakerById("genelec-8351b") as SpeakerSpec;
  const sub = getSpeakerById("electro-voice-x12-128") as SpeakerSpec;

  assert(!!monitor, "Genelec 8351B must exist");
  assert(!!sub, "Electro-Voice X12-128 Subwoofer must exist");

  const outMonitor = simulateSpeakerDSP(testSignal, sampleRate, monitor, { loudnessMatched: true });
  const outSub = simulateSpeakerDSP(testSignal, sampleRate, sub, { loudnessMatched: true });

  // Measure high-frequency energy (2 kHz - 8 kHz)
  const hfEnergyMonitor = computeBandEnergy(outMonitor, sampleRate, 2000, 8000);
  const hfEnergySub = computeBandEnergy(outSub, sampleRate, 2000, 8000);

  assert(hfEnergyMonitor > 0, "Monitor must reproduce HF energy");
  assert(hfEnergySub < hfEnergyMonitor * 0.05, `Subwoofer must sharply attenuate HF energy: sub=${hfEnergySub}, monitor=${hfEnergyMonitor}`);

  // Spectral RMS difference between monitor and subwoofer
  let sumDiffSq = 0;
  for (let i = 0; i < outMonitor.length; i++) {
    const diff = outMonitor[i] - outSub[i];
    sumDiffSq += diff * diff;
  }
  const rmsDiff = Math.sqrt(sumDiffSq / outMonitor.length);
  assert(rmsDiff > 0.05, `Monitor and subwoofer must have substantial RMS difference: got ${rmsDiff.toFixed(4)}`);
});

// -----------------------------------------------------------------------------
// Test 3: Yamaha NS-10M vs Flat Reference Monitor (Presence Peak Verification)
// -----------------------------------------------------------------------------
check("Test 3: Yamaha NS-10M exhibits documented presence boost compared to flat reference monitor", () => {
  const ns10 = getSpeakerById("yamaha-ns10m") as SpeakerSpec;
  const flat = getSpeakerById("genelec-8351b") as SpeakerSpec;

  assert(!!ns10, "NS-10M must exist");
  assert(!!flat, "Genelec 8351B must exist");

  const modelNS10 = getSpeakerResponseModel(ns10);
  const modelFlat = getSpeakerResponseModel(flat);

  // Check 1.6 kHz - 2 kHz presence boost in response models
  const ns10PresenceDb = interpolateLogFrequency(modelNS10.points, 1800);
  const flatPresenceDb = interpolateLogFrequency(modelFlat.points, 1800);

  assert(ns10PresenceDb > 3.0, `NS-10M must exhibit documented >3dB presence hump at 1.8kHz, got ${ns10PresenceDb.toFixed(2)} dB`);
  assert(Math.abs(flatPresenceDb) < 1.0, `Genelec 8351B must be flat at 1.8kHz, got ${flatPresenceDb.toFixed(2)} dB`);

  // Audio DSP verification
  const outNS10 = simulateSpeakerDSP(testSignal, sampleRate, ns10, { loudnessMatched: true });
  const outFlat = simulateSpeakerDSP(testSignal, sampleRate, flat, { loudnessMatched: true });

  const midEnergyNS10 = computeBandEnergy(outNS10, sampleRate, 1400, 2200);
  const midEnergyFlat = computeBandEnergy(outFlat, sampleRate, 1400, 2200);

  assert(midEnergyNS10 > midEnergyFlat * 1.2, `NS-10M must generate more energy in the 1.4-2.2kHz presence band: NS10=${midEnergyNS10.toFixed(5)}, Flat=${midEnergyFlat.toFixed(5)}`);
});

// -----------------------------------------------------------------------------
// Test 4: Raw Mode vs Loudness-Matched Mode
// -----------------------------------------------------------------------------
check("Test 4: Raw mode reflects sensitivity difference; Loudness-Matched equalizes overall level", () => {
  const highSens = getSpeakerById("celestion-v30") as SpeakerSpec; // 100 dB @ 1W/1m
  const lowSens = getSpeakerById("rockford-fosgate-p3") as SpeakerSpec; // 85 dB @ 1W/1m

  assert(!!highSens, "Celestion Vintage 30 must exist");
  assert(!!lowSens, "Rockford Fosgate P3 must exist");

  const sensHigh = highSens.sensitivity?.value || 100;
  const sensLow = lowSens.sensitivity?.value || 85;
  assert(sensHigh > sensLow, `highSens (${sensHigh}) must be greater than lowSens (${sensLow})`);

  // In raw mode, higher sensitivity speaker outputs higher amplitude
  const rawHigh = simulateSpeakerDSP(testSignal, sampleRate, highSens, { loudnessMatched: false });
  const rawLow = simulateSpeakerDSP(testSignal, sampleRate, lowSens, { loudnessMatched: false });

  const rmsRawHigh = computeRms(rawHigh);
  const rmsRawLow = computeRms(rawLow);
  assert(rmsRawHigh > rmsRawLow, `Higher sensitivity speaker (${sensHigh}dB) must be louder than lower sensitivity (${sensLow}dB) in raw mode`);

  // In loudness-matched mode, level difference is normalized so user compares timbre only
  const matchedHigh = simulateSpeakerDSP(testSignal, sampleRate, highSens, { loudnessMatched: true });
  const matchedLow = simulateSpeakerDSP(testSignal, sampleRate, lowSens, { loudnessMatched: true });

  const rmsMatchedHigh = computeRms(matchedHigh);
  const rmsMatchedLow = computeRms(matchedLow);
  const levelRatio = Math.abs(20 * Math.log10(rmsMatchedHigh / rmsMatchedLow));
  assert(levelRatio < 3.5, `Loudness-matched mode should keep broadband RMS within 3.5 dB, got ratio ${levelRatio.toFixed(2)} dB`);
});

// -----------------------------------------------------------------------------
// Test 5: Distance Attenuation (1 / r)
// -----------------------------------------------------------------------------
check("Test 5: Distance attenuation follows inverse-distance law", () => {
  const spec = getSpeakerById("genelec-8351b") as SpeakerSpec;
  const d1 = simulateSpeakerDSP(testSignal, sampleRate, spec, { distanceM: 1.0, loudnessMatched: true });
  const d2 = simulateSpeakerDSP(testSignal, sampleRate, spec, { distanceM: 2.0, loudnessMatched: true });

  const rms1 = computeRms(d1);
  const rms2 = computeRms(d2);

  // Doubling distance reduces free-field amplitude by 50% (-6.02 dB)
  const ratio = rms1 / rms2;
  assert(Math.abs(ratio - 2.0) < 0.05, `Doubling distance must cut linear amplitude in half (expected ~2.0, got ${ratio.toFixed(3)})`);
});

// -----------------------------------------------------------------------------
// Test 6: Off-Axis Directivity Attenuation
// -----------------------------------------------------------------------------
check("Test 6: Off-axis angle applies progressive directivity attenuation", () => {
  const spec = getSpeakerById("genelec-8351b") as SpeakerSpec;
  const onAxis = simulateSpeakerDSP(testSignal, sampleRate, spec, { angleRad: 0.0, loudnessMatched: true });
  const offAxis60 = simulateSpeakerDSP(testSignal, sampleRate, spec, { angleRad: (60 * Math.PI) / 180, loudnessMatched: true });
  const offAxis90 = simulateSpeakerDSP(testSignal, sampleRate, spec, { angleRad: (90 * Math.PI) / 180, loudnessMatched: true });

  const rms0 = computeRms(onAxis);
  const rms60 = computeRms(offAxis60);
  const rms90 = computeRms(offAxis90);

  assert(rms0 > rms60, `On-axis must be louder than 60 deg off-axis: ${rms0.toFixed(4)} <= ${rms60.toFixed(4)}`);
  assert(rms60 > rms90, `60 deg must be louder than 90 deg off-axis: ${rms60.toFixed(4)} <= ${rms90.toFixed(4)}`);
});

// -----------------------------------------------------------------------------
// Test 7: Logarithmic Frequency Interpolation Integrity
// -----------------------------------------------------------------------------
check("Test 7: Logarithmic frequency interpolation is smooth and monotonic", () => {
  const points: ResponsePoint[] = [
    { hz: 20, db: -20 },
    { hz: 100, db: 0 },
    { hz: 1000, db: 0 },
    { hz: 10000, db: -10 }
  ];

  // Midpoint between 20 Hz and 100 Hz in log space is 10^( (log10(20) + log10(100))/2 ) = sqrt(2000) ~= 44.7 Hz
  const midFreq = Math.sqrt(20 * 100);
  const valMid = interpolateLogFrequency(points, midFreq);
  assert(Math.abs(valMid - (-10.0)) < 0.1, `Logarithmic midpoint between -20dB and 0dB should be -10dB, got ${valMid.toFixed(2)}`);

  // Extrapolation checks
  const valSub10 = interpolateLogFrequency(points, 10);
  assert(valSub10 < -20, `Sub-20Hz extrapolation must continue downward slope: got ${valSub10.toFixed(2)}`);

  const val20k = interpolateLogFrequency(points, 20000);
  assert(val20k < -10, `Above 10kHz extrapolation must continue downward slope: got ${val20k.toFixed(2)}`);
});

// -----------------------------------------------------------------------------
// Test 8: Bookshelf (KEF LS50) vs PA System (QSC K12.2 / RCF ART 312)
// -----------------------------------------------------------------------------
check("Test 8: Compact Bookshelf vs High-Output PA Speaker exhibits measurable acoustic divergence", () => {
  const bookshelf = getSpeakerById("kef-ls50") as SpeakerSpec;
  const pa = getSpeakerById("rcf-art312a") as SpeakerSpec;

  assert(!!bookshelf, "KEF LS50 must exist");
  assert(!!pa, "RCF ART 312-A must exist");

  const outBookshelf = simulateSpeakerDSP(testSignal, sampleRate, bookshelf, { loudnessMatched: true });
  const outPA = simulateSpeakerDSP(testSignal, sampleRate, pa, { loudnessMatched: true });

  let sumDiffSq = 0;
  for (let i = 0; i < outBookshelf.length; i++) {
    const diff = outBookshelf[i] - outPA[i];
    sumDiffSq += diff * diff;
  }
  const rmsDiff = Math.sqrt(sumDiffSq / outBookshelf.length);
  assert(rmsDiff > 0.015, `Bookshelf and PA speaker must produce distinct DSP waveforms: rmsDiff=${rmsDiff.toFixed(4)}`);

  // PA horn throat presence (2-4 kHz) vs neutral bookshelf
  const paHornEnergy = computeBandEnergy(outPA, sampleRate, 2000, 4000);
  const bookshelfEnergy = computeBandEnergy(outBookshelf, sampleRate, 2000, 4000);
  assert(paHornEnergy > bookshelfEnergy * 1.05, `PA horn must exhibit higher upper-mid presence than bookshelf: PA=${paHornEnergy.toFixed(5)}, Bookshelf=${bookshelfEnergy.toFixed(5)}`);
});

// -----------------------------------------------------------------------------
// Test 9: Klipschorn (105 dB SPL) vs KEF LS50 (85 dB SPL) Sensitivity Modeling
// -----------------------------------------------------------------------------
check("Test 9: High-Efficiency Horn (105dB) vs Compact Monitor (85dB) reflects 20 dB physical SPL difference", () => {
  const horn = getSpeakerById("klipsch-klipschorn") as SpeakerSpec;
  const monitor = getSpeakerById("kef-ls50") as SpeakerSpec;

  assert(!!horn, "Klipschorn must exist");
  assert(!!monitor, "KEF LS50 must exist");

  const sensHorn = horn.sensitivity?.value || 105;
  const sensMonitor = monitor.sensitivity?.value || 85;
  assert(sensHorn - sensMonitor >= 20, "Klipschorn must be at least 20 dB more sensitive than LS50");

  const rawHorn = simulateSpeakerDSP(testSignal, sampleRate, horn, { loudnessMatched: false });
  const rawMonitor = simulateSpeakerDSP(testSignal, sampleRate, monitor, { loudnessMatched: false });

  const rmsHorn = computeRms(rawHorn);
  const rmsMonitor = computeRms(rawMonitor);
  const measuredRatioDb = 20 * Math.log10(rmsHorn / rmsMonitor);

  // 20 dB base sensitivity difference plus ~1.2 dB physical horn acoustic curve gain
  assert(measuredRatioDb >= 19.0 && measuredRatioDb <= 23.0, `Physical sensitivity ratio should reflect ~20 dB base plus horn gain (~21.2 dB), got ${measuredRatioDb.toFixed(2)} dB`);
});

console.log(`\n=== Speaker Acoustic Difference Tests: ${passed} passed, ${failed} failed ===\n`);
if (failed > 0) {
  console.error("Failures:");
  for (const f of failures) console.error(` - ${f}`);
  process.exit(1);
}
