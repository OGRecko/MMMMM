/**
 * Speaker database integrity tests.
 *
 * Guards the merged/additive database against silent regressions:
 * accidental rebuilds, dropped legacy records, reintroduced duplicates, and
 * reverted manufacturer spec corrections.
 *
 * Run with:  npx tsx src/data/speakers.test.ts
 */

import speakers from "./speakers.json";

let passed = 0;
let failed = 0;
const failures: string[] = [];

function check(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  PASS  ${name}`);
  } catch (err: any) {
    failed++;
    failures.push(`${name}: ${err.message}`);
    console.log(`  FAIL  ${name}\n        ${err.message}`);
  }
}

function assert(cond: any, msg: string) {
  if (!cond) throw new Error(msg);
}

const db = speakers as any[];

console.log("\n=== Speaker database integrity ===\n");

check("total record count is 774", () => {
  assert(Array.isArray(db), "speakers.json is not an array");
  assert(db.length === 774, `expected exactly 774 records, found ${db.length}`);
});

check("80 legacy records preserved", () => {
  const legacy = db.filter((s) => s.overallStatus === "LEGACY");
  assert(legacy.length === 80, `expected 80 LEGACY records, found ${legacy.length}`);
});

check("694 specs-verified records", () => {
  const verified = db.filter((s) => s.overallStatus !== "LEGACY");
  assert(verified.length === 694, `expected exactly 694 non-legacy records, found ${verified.length}`);
  const statuses = new Set(db.map((s) => s.overallStatus));
  for (const st of statuses) {
    assert(
      ["LEGACY", "FULLY_VERIFIED", "PARTIALLY_VERIFIED"].includes(st),
      `unexpected overallStatus value: ${st}`,
    );
  }
});

check("zero duplicate IDs", () => {
  const seen = new Map<string, number>();
  const dupes: string[] = [];
  for (const s of db) {
    assert(typeof s.id === "string" && s.id.length > 0, `record with missing id: ${JSON.stringify(s).slice(0, 80)}`);
    if (seen.has(s.id)) dupes.push(s.id);
    seen.set(s.id, (seen.get(s.id) || 0) + 1);
  }
  assert(dupes.length === 0, `duplicate ids: ${dupes.join(", ")}`);
});

check("zero duplicate brand + model pairs", () => {
  const seen = new Set<string>();
  const dupes: string[] = [];
  for (const s of db) {
    const key = `${String(s.brand).trim().toLowerCase()}|${String(s.model).trim().toLowerCase()}`;
    if (seen.has(key)) dupes.push(key);
    seen.add(key);
  }
  assert(dupes.length === 0, `duplicate brand|model pairs: ${dupes.join(", ")}`);
});

check("known Jensen P10R corrections preserved", () => {
  const s = db.find((x) => x.id === "jensen-p10r");
  assert(s, "jensen-p10r record is missing");
  assert(s.sensitivity.value === 94.2, `sensitivity ${s.sensitivity.value} != 94.2 dB`);
  assert(s.power.value === 25, `power ${s.power.value} != 25 W`);
  assert(s.resonantFreq.value === 97, `Fs ${s.resonantFreq.value} != 97 Hz`);
  assert(s.impedance.value === 8, `impedance ${s.impedance.value} != 8 ohm`);
});

check("known Jensen P12N corrections preserved", () => {
  const s = db.find((x) => x.id === "jensen-p12n");
  assert(s, "jensen-p12n record is missing");
  assert(s.sensitivity.value === 97.5, `sensitivity ${s.sensitivity.value} != 97.5 dB`);
  assert(s.power.value === 50, `power ${s.power.value} != 50 W`);
  assert(s.resonantFreq.value === 90, `Fs ${s.resonantFreq.value} != 90 Hz`);
  assert(s.impedance.value === 8, `impedance ${s.impedance.value} != 8 ohm`);
});

check("every record has the fields the app reads", () => {
  const bad: string[] = [];
  for (const s of db) {
    if (typeof s.brand !== "string" || typeof s.model !== "string") bad.push(`${s.id}: brand/model`);
    if (s.year !== null && typeof s.year !== "number") bad.push(`${s.id}: year must be number|null`);
    for (const f of ["sensitivity", "power", "impedance", "resonantFreq"]) {
      if (s[f] == null) bad.push(`${s.id}: missing ${f}`);
      else if (s[f].value !== null && !Number.isFinite(s[f].value)) bad.push(`${s.id}: ${f}.value not finite`);
    }
  }
  assert(bad.length === 0, `malformed records:\n        ${bad.slice(0, 10).join("\n        ")}`);
});

check("no NaN values anywhere in the database", () => {
  const found: string[] = [];
  const walk = (node: any, path: string) => {
    if (typeof node === "number" && !Number.isFinite(node)) found.push(path);
    else if (node && typeof node === "object") {
      for (const k of Object.keys(node)) walk(node[k], `${path}.${k}`);
    }
  };
  db.forEach((s, i) => walk(s, s.id || `#${i}`));
  assert(found.length === 0, `non-finite numbers at: ${found.join(", ")}`);
});

console.log(`\n=== ${passed} passed, ${failed} failed ===\n`);
if (failed > 0) {
  console.log("Failures:");
  for (const f of failures) console.log(`  - ${f}`);
  process.exit(1);
}
